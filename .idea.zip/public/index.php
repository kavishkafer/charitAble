<?php
require_once '../app/init.php';
require '../app/vendor/autoload.php';
// session_start();
//Init Core library
$init = new Core();
