<?php
class SettingBen{
    private $db;
    public function __construct(){
        $this->db = new Database;
    }
    public function updateProfile($data){
        $this->db->query('Update Beneficiary_Details SET B_Name = :name, B_Address = :address, B_Members = :members,B_Description = :description, B_Tpno = :telephone_number, B_Address = :address, WHERE User_Id = :id');
        //bind values
        $this->db->bind(':name', $data['name']);
        $this->db->bind(':address', $data['address']);
        $this->db->bind(':members', $data['members']);
        $this->db->bind(':description', $data['description']);
        $this->db->bind(':telephone_number', $data['telephone_number']);
        $this->db->bind(':address', $data['address']);
        $this->db->bind(':id', $data['user_id']);
        if($this->db->execute()){
            return true;
        }else{
            return false;
        }


    }
}