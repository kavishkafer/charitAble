<?php require APPROOT . '/views/inc/header.php'; ?>
<?php require APPROOT . '/views/inc/navbar_dons.php'; ?>
<body>
<link rel="stylesheet" href="<?php echo URLROOT;?>/css/donor/style.css">

<div class="container">

<div class="choose-ben">
   <h2>Ongoing Requests</h2> 
</div>


<div class="select">
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Address</th>
                <th>Telephone No</th>
                <th>E-mail</th>
                <th>Quantity</th>
                <th ></th>
                <th ></th>
            </tr>
        </thead>
    
        <tbody>
            <tr>
        <td> 1</td> 
        <td>ABCD</td>
        <td>Colombo</td>
        <td>0116543689</td>
        <td>ABCD@gmail.com</td>
        <td>30</td>
         <td ><a href="#" class="btn2">View Profile</a></td>

         </tr>

         <tr>
        <td> 2</td> 
        <td>ABCD</td>
        <td>Colombo</td>
        <td>0116543689</td>
        <td>ABCD@gmail.com</td>
        <td>30</td>
         <td ><a href="#" class="btn2">View Profile</a></td>

         </tr>

         <tr>
        <td> 3</td> 
        <td>ABCD</td>
        <td>Colombo</td>
        <td>0116543689</td>
        <td>ABCD@gmail.com</td>
        <td>30</td>
         <td ><a href="#" class="btn2">View Profile</a></td>

         </tr>

         <tr>
        <td> 4</td> 
        <td>ABCD</td>
        <td>Colombo</td>
        <td>0116543689</td>
        <td>ABCD@gmail.com</td>
        <td>30</td>
         <td ><a href="#" class="btn2">View Profile</a></td>

         </tr>

    </tbody>
    </table>
</div>

<?php require APPROOT . '/views/inc/footer.php'; ?>